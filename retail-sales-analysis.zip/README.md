
# Retail Sales Analysis & Revenue Optimization

SQL & Tableau project analyzing 80k+ retail transactions to identify seasonal trends,
store-level performance, and pricing recommendations.

Tools: SQL, Tableau, Excel
